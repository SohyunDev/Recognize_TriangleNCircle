#include <opencv2\highgui.hpp>

#include <vector>

IplImage* getOutline(IplImage* shape);

using namespace cv;
int main()
{
	IplImage* outline;
	IplImage* circle;
	if((circle = cvLoadImage("triangle.jpg", CV_LOAD_IMAGE_COLOR))==NULL)
		return -1;
	outline = cvCreateImage(cvSize(circle->width, circle->height), circle->depth, 1);
	outline = getOutline(circle);

		
	cvNamedWindow("output", 1);
	cvShowImage("output", outline);

	cvWaitKey(0);
	cvDestroyWindow("output");
	return 0;

}

IplImage* getOutline(IplImage* shape) {
	IplImage* outline = cvCreateImage(cvSize(shape->width, shape->height), shape->depth, 1);;
	for (int y = 0; y <outline->height; y++) {
		for (int x = 0; x < outline->width; x++) {
			cvSetReal2D(outline, y, x, 255);
		}
	}
	cvSet(outline, CvScalar(255));

	for (int y = 0; y < shape->height; y++) {
		for (int x = 0; x < shape->width; x++) {
			if (cvGet2D(shape, y, x).val[0] == 0 && cvGet2D(shape, y, x).val[1] == 0 && cvGet2D(shape, y, x).val[2] == 0) {
				{
					cvSetReal2D(outline, y, x, 0);
					for (int a = x; a < shape->width; a++) {
						if (cvGet2D(shape, y, a).val[0] == 255 && cvGet2D(shape, y, a).val[1] == 255 && cvGet2D(shape, y, a).val[2] == 255) {
							cvSetReal2D(outline, y, a - 1, 0);
							break;
						}
					}
				}
					break;
			}
		}
	}

	for (int y = 0; y < shape->width; y++) {
		for (int x = 0; x < shape->height; x++) {
			if (cvGet2D(shape, x, y).val[0] == 0 && cvGet2D(shape, x, y).val[1] == 0 && cvGet2D(shape, x, y).val[2] == 0) {
				{
					cvSetReal2D(outline, x, y, 0);
					for (int a = x; a < shape->height; a++) {
						if (cvGet2D(shape, a, y).val[0] == 255 && cvGet2D(shape, a, y).val[1] == 255 && cvGet2D(shape, a, y).val[2] == 255) {
							cvSetReal2D(outline, a-1, y, 0);
							break;
						}
					}
				}
				break;
			}
		}
	}
	return outline;
}
